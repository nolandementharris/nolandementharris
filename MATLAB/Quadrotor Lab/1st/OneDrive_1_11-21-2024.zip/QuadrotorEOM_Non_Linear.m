function var_dot = QuadrotorEOM_Non_Linear(time,aircraft_state_array, g, mass, I, deltaFc, deltaGc);
%% need to create this function for 3.4
end

